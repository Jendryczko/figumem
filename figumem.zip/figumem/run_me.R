####run_me####


#Set your R working directory to the folder that contains the PNG-files for figumem!!!

#Install the magick-package if you do not have done so already (then you will need an internet connection).
if(!require(magick)){
  install.packages("magick")
}

#load the magick-package
library(magick)

#Read in the PNG-files that contain the emblems and outer shapes of figumem for every difficulty.
#Note that every emblem comes in two different sizes ("small" and "large"). This is just for the creation of sharper images.
frame_easy1 <- image_read("frame_easy1.png")
frame_easy2 <- image_read("frame_easy2.png")
frame_easy3 <- image_read("frame_easy3.png")
frame_easy4 <- image_read("frame_easy4.png")
frame_easy5 <- image_read("frame_easy5.png")
frame_easy6 <- image_read("frame_easy6.png")
frame_easy7 <- image_read("frame_easy7.png")
frame_easy8 <- image_read("frame_easy8.png")
frame_easy9 <- image_read("frame_easy9.png")
frame_easy10 <- image_read("frame_easy10.png")
frame_easy11 <- image_read("frame_easy11.png")
frame_easy12 <- image_read("frame_easy12.png")
frame_easy13 <- image_read("frame_easy13.png")
frame_easy14 <- image_read("frame_easy14.png")
frame_easy15 <- image_read("frame_easy15.png")
frame_easy16 <- image_read("frame_easy16.png")
frame_easy17 <- image_read("frame_easy17.png")
frame_easy18 <- image_read("frame_easy18.png")
frame_easy19 <- image_read("frame_easy19.png")
frame_easy20 <- image_read("frame_easy20.png")
frame_medium_hard1 <- image_read("frame_medium_hard1.png")
frame_medium_hard2 <- image_read("frame_medium_hard2.png")
frame_medium_hard3 <- image_read("frame_medium_hard3.png")
frame_medium_hard4 <- image_read("frame_medium_hard4.png")
frame_medium_hard5 <- image_read("frame_medium_hard5.png")
frame_medium_hard6 <- image_read("frame_medium_hard6.png")
frame_medium_hard7 <- image_read("frame_medium_hard7.png")
frame_medium_hard8 <- image_read("frame_medium_hard8.png")
frame_medium_hard9 <- image_read("frame_medium_hard9.png")
frame_medium_hard10 <- image_read("frame_medium_hard10.png")
frame_medium_hard11 <- image_read("frame_medium_hard11.png")
frame_medium_hard12 <- image_read("frame_medium_hard12.png")
frame_medium_hard13 <- image_read("frame_medium_hard13.png")
frame_medium_hard14 <- image_read("frame_medium_hard14.png")
frame_medium_hard15 <- image_read("frame_medium_hard15.png")
frame_medium_hard16 <- image_read("frame_medium_hard16.png")
frame_medium_hard17 <- image_read("frame_medium_hard17.png")
frame_medium_hard18 <- image_read("frame_medium_hard18.png")
frame_medium_hard19 <- image_read("frame_medium_hard19.png")
frame_medium_hard20 <- image_read("frame_medium_hard20.png")
emblem_small_easy_medium1 <- image_read("emblem_small_easy_medium1.png")
emblem_small_easy_medium2 <- image_read("emblem_small_easy_medium2.png")
emblem_small_easy_medium3 <- image_read("emblem_small_easy_medium3.png")
emblem_small_easy_medium4 <- image_read("emblem_small_easy_medium4.png")
emblem_small_easy_medium5 <- image_read("emblem_small_easy_medium5.png")
emblem_small_easy_medium6 <- image_read("emblem_small_easy_medium6.png")
emblem_small_easy_medium7 <- image_read("emblem_small_easy_medium7.png")
emblem_small_easy_medium8 <- image_read("emblem_small_easy_medium8.png")
emblem_small_easy_medium9 <- image_read("emblem_small_easy_medium9.png")
emblem_small_easy_medium10 <- image_read("emblem_small_easy_medium10.png")
emblem_small_easy_medium11 <- image_read("emblem_small_easy_medium11.png")
emblem_small_easy_medium12 <- image_read("emblem_small_easy_medium12.png")
emblem_small_easy_medium13 <- image_read("emblem_small_easy_medium13.png")
emblem_small_easy_medium14 <- image_read("emblem_small_easy_medium14.png")
emblem_small_easy_medium15 <- image_read("emblem_small_easy_medium15.png")
emblem_small_easy_medium16 <- image_read("emblem_small_easy_medium16.png")
emblem_small_easy_medium17 <- image_read("emblem_small_easy_medium17.png")
emblem_small_easy_medium18 <- image_read("emblem_small_easy_medium18.png")
emblem_small_easy_medium19 <- image_read("emblem_small_easy_medium19.png")
emblem_small_easy_medium20 <- image_read("emblem_small_easy_medium20.png")
emblem_large_easy_medium1 <- image_read("emblem_large_easy_medium1.png")
emblem_large_easy_medium2 <- image_read("emblem_large_easy_medium2.png")
emblem_large_easy_medium3 <- image_read("emblem_large_easy_medium3.png")
emblem_large_easy_medium4 <- image_read("emblem_large_easy_medium4.png")
emblem_large_easy_medium5 <- image_read("emblem_large_easy_medium5.png")
emblem_large_easy_medium6 <- image_read("emblem_large_easy_medium6.png")
emblem_large_easy_medium7 <- image_read("emblem_large_easy_medium7.png")
emblem_large_easy_medium8 <- image_read("emblem_large_easy_medium8.png")
emblem_large_easy_medium9 <- image_read("emblem_large_easy_medium9.png")
emblem_large_easy_medium10 <- image_read("emblem_large_easy_medium10.png")
emblem_large_easy_medium11 <- image_read("emblem_large_easy_medium11.png")
emblem_large_easy_medium12 <- image_read("emblem_large_easy_medium12.png")
emblem_large_easy_medium13 <- image_read("emblem_large_easy_medium13.png")
emblem_large_easy_medium14 <- image_read("emblem_large_easy_medium14.png")
emblem_large_easy_medium15 <- image_read("emblem_large_easy_medium15.png")
emblem_large_easy_medium16 <- image_read("emblem_large_easy_medium16.png")
emblem_large_easy_medium17 <- image_read("emblem_large_easy_medium17.png")
emblem_large_easy_medium18 <- image_read("emblem_large_easy_medium18.png")
emblem_large_easy_medium19 <- image_read("emblem_large_easy_medium19.png")
emblem_large_easy_medium20 <- image_read("emblem_large_easy_medium20.png")
emblem_small_hard1 <- image_read("emblem_small_hard1.png")
emblem_small_hard2 <- image_read("emblem_small_hard2.png")
emblem_small_hard3 <- image_read("emblem_small_hard3.png")
emblem_small_hard4 <- image_read("emblem_small_hard4.png")
emblem_small_hard5 <- image_read("emblem_small_hard5.png")
emblem_small_hard6 <- image_read("emblem_small_hard6.png")
emblem_small_hard7 <- image_read("emblem_small_hard7.png")
emblem_small_hard8 <- image_read("emblem_small_hard8.png")
emblem_small_hard9 <- image_read("emblem_small_hard9.png")
emblem_small_hard10 <- image_read("emblem_small_hard10.png")
emblem_small_hard11 <- image_read("emblem_small_hard11.png")
emblem_small_hard12 <- image_read("emblem_small_hard12.png")
emblem_small_hard13 <- image_read("emblem_small_hard13.png")
emblem_small_hard14 <- image_read("emblem_small_hard14.png")
emblem_small_hard15 <- image_read("emblem_small_hard15.png")
emblem_small_hard16 <- image_read("emblem_small_hard16.png")
emblem_small_hard17 <- image_read("emblem_small_hard17.png")
emblem_small_hard18 <- image_read("emblem_small_hard18.png")
emblem_small_hard19 <- image_read("emblem_small_hard19.png")
emblem_small_hard20 <- image_read("emblem_small_hard20.png")
emblem_large_hard1 <- image_read("emblem_large_hard1.png")
emblem_large_hard2 <- image_read("emblem_large_hard2.png")
emblem_large_hard3 <- image_read("emblem_large_hard3.png")
emblem_large_hard4 <- image_read("emblem_large_hard4.png")
emblem_large_hard5 <- image_read("emblem_large_hard5.png")
emblem_large_hard6 <- image_read("emblem_large_hard6.png")
emblem_large_hard7 <- image_read("emblem_large_hard7.png")
emblem_large_hard8 <- image_read("emblem_large_hard8.png")
emblem_large_hard9 <- image_read("emblem_large_hard9.png")
emblem_large_hard10 <- image_read("emblem_large_hard10.png")
emblem_large_hard11 <- image_read("emblem_large_hard11.png")
emblem_large_hard12 <- image_read("emblem_large_hard12.png")
emblem_large_hard13 <- image_read("emblem_large_hard13.png")
emblem_large_hard14 <- image_read("emblem_large_hard14.png")
emblem_large_hard15 <- image_read("emblem_large_hard15.png")
emblem_large_hard16 <- image_read("emblem_large_hard16.png")
emblem_large_hard17 <- image_read("emblem_large_hard17.png")
emblem_large_hard18 <- image_read("emblem_large_hard18.png")
emblem_large_hard19 <- image_read("emblem_large_hard19.png")
emblem_large_hard20 <- image_read("emblem_large_hard20.png")



###################################################################

#Define the "figumem_item" function to create a figumem item.

figumem_item<- function (objn = 20, mode = "classic", challenge = 1, seed=sample(1:999999999,1), ntrys=100) {     
  
  if (mode != "classic" & mode != "classic_paper" &  mode != "draw" & mode != "draw_random")  {                                   
    stop("Only modes 'classic', 'classic_paper', 'draw' and 'draw_random'  are currently supported!")
  }
  
  if ((objn %in% c(1:20))==F)  {                              
    stop("'objn' must be a natural number between 1 and 20!")
  }
  
  if ((challenge %in% c(1:3))==F)  {                             
    stop("'challenge' must be a natural number between 1 and 3! Choose 1 for easy, 2 for medium, and 3 for hard difficulty.")
  }
  
  if (ntrys < 1)  {                          
    stop("'ntrys' must be a natural number greater than 1.")
  }
  
  
  if(challenge== 1){
    a_g<-c(frame_easy1,  
           frame_easy2, 
           frame_easy3, 
           frame_easy4,
           frame_easy5,
           frame_easy6, 
           frame_easy7, 
           frame_easy8,
           frame_easy9, 
           frame_easy10, 
           frame_easy11, 
           frame_easy12, 
           frame_easy13,
           frame_easy14,
           frame_easy15,
           frame_easy16,
           frame_easy17,
           frame_easy18, 
           frame_easy19, 
           frame_easy20)
    i_k<-c(emblem_small_easy_medium1,  
           emblem_small_easy_medium2, 
           emblem_small_easy_medium3, 
           emblem_small_easy_medium4,
           emblem_small_easy_medium5,
           emblem_small_easy_medium6, 
           emblem_small_easy_medium7, 
           emblem_small_easy_medium8,
           emblem_small_easy_medium9, 
           emblem_small_easy_medium10, 
           emblem_small_easy_medium11, 
           emblem_small_easy_medium12, 
           emblem_small_easy_medium13,
           emblem_small_easy_medium14,
           emblem_small_easy_medium15,
           emblem_small_easy_medium16,
           emblem_small_easy_medium17,
           emblem_small_easy_medium18, 
           emblem_small_easy_medium19, 
           emblem_small_easy_medium20)
    i_g<-c(emblem_large_easy_medium1, 
           emblem_large_easy_medium2, 
           emblem_large_easy_medium3, 
           emblem_large_easy_medium4,
           emblem_large_easy_medium5,
           emblem_large_easy_medium6, 
           emblem_large_easy_medium7, 
           emblem_large_easy_medium8,
           emblem_large_easy_medium9, 
           emblem_large_easy_medium10, 
           emblem_large_easy_medium11, 
           emblem_large_easy_medium12, 
           emblem_large_easy_medium13,
           emblem_large_easy_medium14,
           emblem_large_easy_medium15,
           emblem_large_easy_medium16,
           emblem_large_easy_medium17,
           emblem_large_easy_medium18, 
           emblem_large_easy_medium19, 
           emblem_large_easy_medium20)
  }
  
  if(challenge== 2){
    a_g<-c(frame_medium_hard1,  
           frame_medium_hard2, 
           frame_medium_hard3, 
           frame_medium_hard4,
           frame_medium_hard5,
           frame_medium_hard6, 
           frame_medium_hard7, 
           frame_medium_hard8,
           frame_medium_hard9, 
           frame_medium_hard10, 
           frame_medium_hard11, 
           frame_medium_hard12, 
           frame_medium_hard13,
           frame_medium_hard14,
           frame_medium_hard15,
           frame_medium_hard16,
           frame_medium_hard17,
           frame_medium_hard18, 
           frame_medium_hard19, 
           frame_medium_hard20)
    i_k<-c(emblem_small_easy_medium1,  
           emblem_small_easy_medium2, 
           emblem_small_easy_medium3, 
           emblem_small_easy_medium4,
           emblem_small_easy_medium5,
           emblem_small_easy_medium6, 
           emblem_small_easy_medium7, 
           emblem_small_easy_medium8,
           emblem_small_easy_medium9, 
           emblem_small_easy_medium10, 
           emblem_small_easy_medium11, 
           emblem_small_easy_medium12, 
           emblem_small_easy_medium13,
           emblem_small_easy_medium14,
           emblem_small_easy_medium15,
           emblem_small_easy_medium16,
           emblem_small_easy_medium17,
           emblem_small_easy_medium18, 
           emblem_small_easy_medium19, 
           emblem_small_easy_medium20)
    i_g<-c(emblem_large_easy_medium1,  
           emblem_large_easy_medium2, 
           emblem_large_easy_medium3, 
           emblem_large_easy_medium4,
           emblem_large_easy_medium5,
           emblem_large_easy_medium6, 
           emblem_large_easy_medium7, 
           emblem_large_easy_medium8,
           emblem_large_easy_medium9, 
           emblem_large_easy_medium10, 
           emblem_large_easy_medium11, 
           emblem_large_easy_medium12, 
           emblem_large_easy_medium13,
           emblem_large_easy_medium14,
           emblem_large_easy_medium15,
           emblem_large_easy_medium16,
           emblem_large_easy_medium17,
           emblem_large_easy_medium18, 
           emblem_large_easy_medium19, 
           emblem_large_easy_medium20)
  }
  
  if(challenge== 3){
    a_g<-c(frame_medium_hard1,  
           frame_medium_hard2, 
           frame_medium_hard3, 
           frame_medium_hard4,
           frame_medium_hard5,
           frame_medium_hard6, 
           frame_medium_hard7, 
           frame_medium_hard8,
           frame_medium_hard9, 
           frame_medium_hard10, 
           frame_medium_hard11, 
           frame_medium_hard12, 
           frame_medium_hard13,
           frame_medium_hard14,
           frame_medium_hard15,
           frame_medium_hard16,
           frame_medium_hard17,
           frame_medium_hard18, 
           frame_medium_hard19, 
           frame_medium_hard20)
    i_k<-c(emblem_small_hard1,  
           emblem_small_hard2, 
           emblem_small_hard3, 
           emblem_small_hard4,
           emblem_small_hard5,
           emblem_small_hard6, 
           emblem_small_hard7, 
           emblem_small_hard8,
           emblem_small_hard9, 
           emblem_small_hard10, 
           emblem_small_hard11, 
           emblem_small_hard12, 
           emblem_small_hard13,
           emblem_small_hard14,
           emblem_small_hard15,
           emblem_small_hard16,
           emblem_small_hard17,
           emblem_small_hard18, 
           emblem_small_hard19, 
           emblem_small_hard20)
    i_g<-c(emblem_large_hard1,  
           emblem_large_hard2, 
           emblem_large_hard3, 
           emblem_large_hard4,
           emblem_large_hard5,
           emblem_large_hard6, 
           emblem_large_hard7, 
           emblem_large_hard8,
           emblem_large_hard9, 
           emblem_large_hard10, 
           emblem_large_hard11, 
           emblem_large_hard12, 
           emblem_large_hard13,
           emblem_large_hard14,
           emblem_large_hard15,
           emblem_large_hard16,
           emblem_large_hard17,
           emblem_large_hard18, 
           emblem_large_hard19, 
           emblem_large_hard20)
  }
  
  set.seed(seed)
  a<-sample(20,objn,replace=F)                                
  b<-sample(20,objn,replace=F)                              
  ob_list<-list()
  
  
  for ( i in 1:objn){
    ob_list[[i]]<-image_border(image_scale(image_mosaic(c(a_g[a[i]],i_k[b[i]]), 'Add'), "300x300"),"white","20x20") 
  }
  
  if(objn==20){                                                              
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))     
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]],ob_list[[15]],ob_list[[16]]))
    l5<-image_append(c(ob_list[[17]],ob_list[[18]],ob_list[[19]],ob_list[[20]]))
    item_memo<-image_append(c(l1,l2,l3,l4,l5), stack=T)
  }
  
  if(objn==19){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]],ob_list[[15]],ob_list[[16]]))
    l5<-image_append(c(ob_list[[17]],ob_list[[18]],ob_list[[19]]))
    item_memo<-image_append(c(l1,l2,l3,l4,l5), stack=T)
  }
  
  if(objn==18){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]],ob_list[[15]],ob_list[[16]]))
    l5<-image_append(c(ob_list[[17]],ob_list[[18]]))
    item_memo<-image_append(c(l1,l2,l3,l4,l5), stack=T)
  }
  
  if(objn==17){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]],ob_list[[15]],ob_list[[16]]))
    l5<-image_append(c(ob_list[[17]]))
    item_memo<-image_append(c(l1,l2,l3,l4,l5), stack=T)
  }
  
  if(objn==16){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]],ob_list[[15]],ob_list[[16]]))
    item_memo<-image_append(c(l1,l2,l3,l4), stack=T)
  }
  
  if(objn==15){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]],ob_list[[15]]))
    item_memo<-image_append(c(l1,l2,l3,l4), stack=T)
  }
  
  if(objn==14){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]],ob_list[[14]]))
    item_memo<-image_append(c(l1,l2,l3,l4), stack=T)
  }
  
  if(objn==13){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    l4<-image_append(c(ob_list[[13]]))
    item_memo<-image_append(c(l1,l2,l3,l4), stack=T)
  }
  
  if(objn==12){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]],ob_list[[12]]))
    item_memo<-image_append(c(l1,l2,l3), stack=T)
  }
  
  if(objn==11){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]],ob_list[[11]]))
    item_memo<-image_append(c(l1,l2,l3), stack=T)
  }
  
  if(objn==10){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]],ob_list[[10]]))
    item_memo<-image_append(c(l1,l2,l3), stack=T)
  }
  
  if(objn==9){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    l3<-image_append(c(ob_list[[9]]))
    item_memo<-image_append(c(l1,l2,l3), stack=T)
  }
  
  if(objn==8){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]],ob_list[[8]]))
    item_memo<-image_append(c(l1,l2), stack=T)
  }
  
  if(objn==7){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]],ob_list[[7]]))
    item_memo<-image_append(c(l1,l2), stack=T)
  }
  
  if(objn==6){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]],ob_list[[6]]))
    item_memo<-image_append(c(l1,l2), stack=T)
  }
  
  if(objn==5){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    l2<-image_append(c(ob_list[[5]]))
    item_memo<-image_append(c(l1,l2), stack=T)
  }
  
  if(objn==4){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]],ob_list[[4]]))
    item_memo<-image_append(c(l1), stack=T)
  }
  
  if(objn==3){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]],ob_list[[3]]))
    item_memo<-image_append(c(l1), stack=T)
  }
  
  if(objn==2){
    l1<-image_append(c(ob_list[[1]],ob_list[[2]]))
    item_memo<-image_append(c(l1), stack=T)
  }
  
  if(objn==1){
    l1<-image_append(c(ob_list[[1]]))
    item_memo<-image_append(c(l1), stack=T)
  }
  
  item_memo<-image_scale(item_memo, "640x615")
  
  
  if (mode == "classic") {                                    
    opt_list<-list() 
    discount<-rep(3,20)
    
    for (i in 1:objn){
      upper<-image_scale(i_g[b[i]], "200x200")  
      target<-image_border(image_scale(a_g[a[i]], "80x80"), "white","10x10")   
      
      success <- F                      
      current_try <- 1
      while(!success & current_try <= ntrys){
        p<-sample(20,1)
        d1<-image_border(image_scale(a_g[p], "80x80"), "white","10x10")
        success<-(p != a[i] & discount[p] > 0)
        current_try <- current_try + 1
        if (current_try > ntrys) {
          warning(paste0("could not decide for first distractor of object ",i,". Returning NA. Try again!"))
          return(NA)
        }
      }
      
      discount[p]<-discount[p]-1
      
      success <- F    
      current_try <- 1             
      while(!success & current_try <= ntrys){
        q<-sample(20,1)
        d2<-image_border(image_scale(a_g[q], "80x80"), "white","10x10")
        success<-(  q != a[i]  & q != p & discount[q] > 0)
        current_try <- current_try + 1
        if (current_try > ntrys) {
          warning(paste0("could not decide for second distractor of object ",i,". Returning NA. Try again!"))
          return(NA)
        }
      }  
      
      discount[q]<-discount[q]-1
      
      success <- F                     
      current_try <- 1
      while(!success & current_try <= ntrys){ 
        r <- sample(20,1)
        d3<-image_border(image_scale(a_g[r], "80x80"), "white","10x10")
        success<-( r != a[i] & r != p & r != q & discount[r] > 0)
        current_try <- current_try + 1
        if (current_try > ntrys) {
          warning(paste0("could not decide for third distractor of object ",i,". Returning NA. Try again!"))
          return(NA)
        }
      } 
      
      discount[r]<-discount[r]-1
      
      lower<-image_append(sample(c(target,d1,d2,d3)))   
      opt_list[[i]]<-c(upper,target,d1,d2,d3)
    }
    item_list<-list(item_memo, opt_list)
    class(item_list) <- "figumem_classic"
    
    return(item_list)
  }
  
  
  
  if (mode == "classic_paper") {                                    
    opt_list<-list() 
    discount<-rep(3,20)
    
    for (i in 1:objn){
      upper<-image_scale(i_g[b[i]], "200x200")  
      target<-image_scale(a_g[a[i]], "50x50")   
      
      success <- F                      
      current_try <- 1
      while(!success & current_try <= ntrys){
        p<-sample(20,1)
        d1<-image_scale(a_g[p], "50x50")
        success<-(p != a[i] & discount[p] > 0)
        current_try <- current_try + 1
        if (current_try > ntrys) {
          warning(paste0("could not decide for first distractor of object ",i,". Returning NA. Try again!"))
          return(NA)
        }
      }
      discount[p]<-discount[p]-1
      
      success <- F     
      current_try <- 1 
      while(!success & current_try <= ntrys){
        q<-sample(20,1)
        d2<-image_scale(a_g[q], "50x50")
        success<-(  q != a[i]  & q != p & discount[q] > 0)
        current_try <- current_try + 1
        if (current_try > ntrys) {
          warning(paste0("could not decide for second distractor of object ",i,". Returning NA. Try again!"))
          return(NA)
        }
      }
      discount[q]<-discount[q]-1
      
      success <- F                     
      current_try <- 1
      while(!success & current_try <= ntrys){
        r <- sample(20,1)
        d3<-image_scale(a_g[r], "50x50")
        success<-( r != a[i] & r != p & r != q & discount[r] > 0)
        current_try <- current_try + 1
        if (current_try > ntrys) {
          warning(paste0("could not decide for third distractor of object ",i,". Returning NA. Try again!"))
          return(NA)
        }
      }
      discount[r]<-discount[r]-1
      
      lower<-image_append(sample(c(target,d1,d2,d3)))   
      opt_list[[i]]<-image_border(image_append(c(upper,lower),stack=T), "white","20x20")  
    }
    
    opt_list2<-sample(opt_list)  
    
    if (objn == 20){                                                                   
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]])) 
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]],opt_list2[[15]],opt_list2[[16]]))
      li5<-image_append(c(opt_list2[[17]],opt_list2[[18]],opt_list2[[19]],opt_list2[[20]]))
      item_answ<-image_append(c(li1,li2,li3,li4,li5), stack=T)
    }
    
    if (objn == 19){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]],opt_list2[[15]],opt_list2[[16]]))
      li5<-image_append(c(opt_list2[[17]],opt_list2[[18]],opt_list2[[19]]))
      item_answ<-image_append(c(li1,li2,li3,li4,li5), stack=T)
    }
    
    if (objn == 18){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]],opt_list2[[15]],opt_list2[[16]]))
      li5<-image_append(c(opt_list2[[17]],opt_list2[[18]]))
      item_answ<-image_append(c(li1,li2,li3,li4,li5), stack=T)
    }
    
    if (objn == 17){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]],opt_list2[[15]],opt_list2[[16]]))
      li5<-image_append(c(opt_list2[[17]]))
      item_answ<-image_append(c(li1,li2,li3,li4,li5), stack=T)
    }
    
    if (objn == 16){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]],opt_list2[[15]],opt_list2[[16]]))
      item_answ<-image_append(c(li1,li2,li3,li4), stack=T)
    }
    
    if (objn == 15){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]],opt_list2[[15]]))
      item_answ<-image_append(c(li1,li2,li3,li4), stack=T)
    }
    
    if (objn == 14){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]],opt_list2[[14]]))
      item_answ<-image_append(c(li1,li2,li3,li4), stack=T)
    }
    
    if (objn == 13){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      li4<-image_append(c(opt_list2[[13]]))
      item_answ<-image_append(c(li1,li2,li3,li4), stack=T)
    }
    
    if (objn == 12){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]],opt_list2[[12]]))
      item_answ<-image_append(c(li1,li2,li3), stack=T)
    }
    
    if (objn == 11){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]],opt_list2[[11]]))
      item_answ<-image_append(c(li1,li2,li3), stack=T)
    }
    
    if (objn == 10){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]],opt_list2[[10]]))
      item_answ<-image_append(c(li1,li2,li3), stack=T)
    }
    
    if (objn == 9){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      li3<-image_append(c(opt_list2[[9]]))
      item_answ<-image_append(c(li1,li2,li3), stack=T)
    }
    
    if (objn == 8){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]],opt_list2[[8]]))
      item_answ<-image_append(c(li1,li2), stack=T)
    }
    
    if (objn == 7){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]],opt_list2[[7]]))
      item_answ<-image_append(c(li1,li2), stack=T)
    }
    
    if (objn == 6){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]],opt_list2[[6]]))
      item_answ<-image_append(c(li1,li2), stack=T)
    }
    
    if (objn == 5){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      li2<-image_append(c(opt_list2[[5]]))
      item_answ<-image_append(c(li1,li2), stack=T)
    }
    
    if (objn == 4){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]],opt_list2[[4]]))
      item_answ<-image_append(c(li1), stack=T)
    }
    
    if (objn == 3){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]],opt_list2[[3]]))
      item_answ<-image_append(c(li1), stack=T)
    }
    
    if (objn == 2){
      li1<-image_append(c(opt_list2[[1]],opt_list2[[2]]))
      item_answ<-image_append(c(li1), stack=T)
    }
    
    if (objn == 1){
      li1<-image_append(c(opt_list2[[1]]))
      item_answ<-image_append(c(li1), stack=T)
    }
    
    complete_item <- list(item_memo, item_answ)
    class(complete_item) <- "figumem_classic_paper"
    return(complete_item)
  }
  
  
  
  if (mode == "draw") {  
    dr_list<-list()
    for ( i in 1:objn){
      dr_list[[i]]<-image_border(i_k[b[i]],color = "white", geometry = "20x20") 
    }
    
    if(objn==20){                                                              
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))     
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]],dr_list[[18]],dr_list[[19]],dr_list[[20]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==19){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]],dr_list[[18]],dr_list[[19]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==18){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]],dr_list[[18]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==17){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==16){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==15){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==14){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==13){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==12){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==11){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==10){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==9){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==8){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==7){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==6){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    
    if(objn==5){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==4){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    if(objn==3){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    
    if(objn==2){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    if(objn==1){
      l1<-image_append(c(dr_list[[1]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    item_answ<-image_scale(item_answ, "640x615")
    
    complete_item <- list(item_memo, item_answ)
    class(complete_item) <- "figumem_draw"
    return(complete_item)
  }
  
  
  
  if (mode == "draw_random") {  
    dr_list<-list()
    for ( i in 1:objn){
      dr_list[[i]]<-image_border(i_k[b[i]],color = "white", geometry = "20x20")
    }
    dr_list <- sample(dr_list)
    
    if(objn==20){                                                           
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))     
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]],dr_list[[18]],dr_list[[19]],dr_list[[20]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==19){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]],dr_list[[18]],dr_list[[19]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==18){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]],dr_list[[18]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==17){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      l5<-image_append(c(dr_list[[17]]))
      item_answ<-image_append(c(l1,l2,l3,l4,l5), stack=T)
    }
    
    if(objn==16){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]],dr_list[[16]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==15){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]],dr_list[[15]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==14){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]],dr_list[[14]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==13){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      l4<-image_append(c(dr_list[[13]]))
      item_answ<-image_append(c(l1,l2,l3,l4), stack=T)
    }
    
    if(objn==12){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]],dr_list[[12]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==11){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]],dr_list[[11]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==10){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]],dr_list[[10]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==9){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      l3<-image_append(c(dr_list[[9]]))
      item_answ<-image_append(c(l1,l2,l3), stack=T)
    }
    
    if(objn==8){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]],dr_list[[8]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==7){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]],dr_list[[7]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==6){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]],dr_list[[6]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==5){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      l2<-image_append(c(dr_list[[5]]))
      item_answ<-image_append(c(l1,l2), stack=T)
    }
    
    if(objn==4){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]],dr_list[[4]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    if(objn==3){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]],dr_list[[3]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    if(objn==2){
      l1<-image_append(c(dr_list[[1]],dr_list[[2]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    if(objn==1){
      l1<-image_append(c(dr_list[[1]]))
      item_answ<-image_append(c(l1), stack=T)
    }
    
    item_answ<-image_scale(item_answ, "640x615")
    
    complete_item <- list(item_memo, item_answ)
    class(complete_item) <- "figumem_draw_random"
    return(complete_item)
  }
}  



###############################################################

#Define the "figumem_write" function to save figumem items in PNG-format.

figumem_write <-function (item, name= "figural_memory_item"){
  if(class(item) == "figumem_classic") {
    image_write(item[[1]], path= paste0(name,"_display.png"), format="png")
    for(b in 1:length(item[[2]])){
      image_write(item[[2]][[b]][1], path= paste0(name,"_stimulus_",b,"_emblem.png"), format="png")
      image_write(item[[2]][[b]][2], path= paste0(name,"_stimulus_",b,"_target.png"), format="png")
      for(c in 1:3){
        image_write(item[[2]][[b]][c+2], path= paste0(name,"_stimulus_",b,"_distractor_",c,".png"), format="png")
      } 
    }
  }  
  if(class(item) == "figumem_classic_paper" | class(item) == "figumem_draw" | class(item) == "figumem_draw_random"){
    image_write(item[[1]], path = paste0(name,"_display.png"), format = "png")
    image_write(item[[2]], path = paste0(name,"_choices.png"), format = "png")
  }
  if(class(item) != "figumem_classic" & class(item) != "figumem_classic_paper" & class(item) != "figumem_draw" & class(item) != "figumem_draw_random") 
  {stop("Can only write items of classes 'figumem_classic', 'figumem_cassic_paper', 'figumem_draw' and 'figumem_draw_random'!")}
}

